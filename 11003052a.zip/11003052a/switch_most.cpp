#include <iostream>
#include <cstring>
using namespace std;
//讀取檔案
#include <fstream> //標頭檔
#include <string>
#include <unordered_map>//找最少

void readFile() {
  ifstream file("oop.txt"); // 開啟檔案

  if (!file.is_open()) { // 開啟
    cout << "Failed to open file." << endl;
    return;
  }

  string line;
  while (getline(file, line)) { // while 讀取檔案
    cout << line << endl; // 將讀取到的內容輸出
  }

  file.close(); // 關閉檔案
}

//字數500內加入a到z的基本值

int main() {
    char str[500];
    int count[26] = {0};
    cout << "輸入字 ";
    cin >> str;
    int len = strlen(str);
    for (int i = 0; i < len; i++) {
        switch(str[i]) {
            case 'a':
            case 'A':
                count[0]++;
                break;
            case 'b':
            case 'B':
                count[1]++;
                break;
            case 'c':
            case 'C':
                count[2]++;
                break;
            case 'd':
            case 'D':
                count[3]++;
                break;
            case 'e':
            case 'E':
                count[4]++;
                break;
            case 'f':
            case 'F':
                count[5]++;
                break;
            case 'g':
            case 'G':
                count[6]++;
                break;
            case 'h':
            case 'H':
                count[7]++;
                break;
            case 'i':
            case 'I':
                count[8]++;
            break;
            case 'j':
            case 'J':
                count[9]++;
                break;
            case 'k':
            case 'K':
                count[10]++;
                break;
            case 'l':
            case 'L':
                count[11]++;
                break;
            case 'm':
            case 'M':
                count[12]++;
                break;
            case 'n':
            case 'N':
                count[13]++;
                break;
            case 'o':
            case 'O':
                count[14]++;
                break;
            case 'p':
            case 'P':
                count[15]++;
                break;
            case 'q':
            case 'Q':
                count[16]++;
                break;
            case 'r':
            case 'R':
                count[17]++;
                break;
            case 's':
            case 'S':
                count[18]++;
                break;
            case 't':
            case 'T':
                count[19]++;
                break;
            case 'u':
            case 'U':
                count[20]++;
                break;
            case 'v':
            case 'V':
                count[21]++;
                break;
            case 'w':
            case 'W':
                count[22]++;
                break;
            case 'X':
            case 'x':
                count[23]++;
                break;
            case 'y':
            case 'Y':
                count[24]++;
                break;
            case 'z':
            case 'Z':
                count[25]++;
                break;
            default:
                break;
        }
    }

    for (int i = 0; i < 26; i++) {
        cout << (char)('A' + i) << ": " << count[i] << endl;
    }
    int max_count = 0;     
char max_char = '\0';  

for (char c = 'a'; c <= 'z'; c++) {
    if (count[c - 'a'] > max_count) {
        max_count = count[c - 'a'];
        max_char = c;
    }
}

if (max_count > 0) {
    cout << "出現最多次的是 " << max_char << ", 出現 " << max_count << " 次" << endl;
} else {
    cout << "No character appears in the input string." << endl;
}
//找最少
void countChars() ;
  string input;
  unordered_map<char, int> charCount;

  // 讀取使用者輸入的字串
  cout << "請輸入字串：";
  getline(cin, input);

  // 計算每個英文字母出現的次數
  for (char c : input) {
    if (isalpha(c)) {
      charCount[tolower(c)]++;
    }
  }
  // 尋找出現次數最少的英文字母
  while (!charCount.empty()) {
    char minChar = '\0';
    int minCount = -1;
    for (auto it = charCount.begin(); it != charCount.end(); it++) {
      if (minCount < 0 || it->second < minCount) {
        minChar = it->first;
        minCount = it->second;
      }
    }
    cout << "字母 " << minChar << " 出現次數最少，共 " << minCount << " 次" << endl;
    charCount.erase(minChar);
  }
}
