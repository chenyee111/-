#include <iostream>
#include <vector>
using namespace std;

int main() {
  vector<int> my_vector(27, 0);

  for (int i = 0; i < my_vector.size(); i++) {
  cout << my_vector[i] << " ";
  }
  cout << endl;

  return 0;
}
